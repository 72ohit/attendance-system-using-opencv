import tkinter as tk
from pandastable import Table
import pandas as pd

df = pd.read_csv("C:/Users/Rohit/Desktop/desktop/attendance_system-master/StudentDetails/StudentDetails.csv")

root = tk.Tk()
root.title('PandasTable Example')

frame = tk.Frame(root)
frame.pack(fill='both', expand=True)

pt = Table(frame, dataframe=df)
pt.show()


root.mainloop()